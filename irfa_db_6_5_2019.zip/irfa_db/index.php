<!DOCTYPE html>
<html>
<head>
	<title>Irfa DB</title>
	<link rel="stylesheet" type="text/css" href="css/stylee.css">
</head>
<body>
	<?php 
if (isset($_GET['pesan'])) {
	if ($_GET['pesan']== "gagal") {
		echo "Login gagal! Username dan Password salah!";
	}else if($_GET['pesan']=="logout"){
		echo "Anda telah berhasil logout";
	}else if($_GET['pesan']=="belum_login"){
		echo "Anda harus login terlebih dahulu";
	}
}

if (isset($_GET['page'])) {
	$page=$_GET['page'];
	switch ($page) {
		case 'register':
			include "register.php";
			break;
		default:
			echo "<center><h1>404 Page Not Found<h1></center>";
			break;
	}
}else{
	include "login.php";
}
	 ?>
</body>
</html>