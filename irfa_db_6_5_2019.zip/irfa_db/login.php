<div class="masuk">
<form action="submit_login.php" method="post">
	<label>Username</label>
	<input class="col_masuk" type="text" name="username" placeholder="Username...">
	<label>Password</label>
	<input class="col_masuk" type="password" name="password" placeholder="Password...">

	<input class="tombol" type="submit" value="login">
	<center class="tengah">
		<a href="index.php?page=register" class="register">Register</a>
	</center>
</form>
</div>